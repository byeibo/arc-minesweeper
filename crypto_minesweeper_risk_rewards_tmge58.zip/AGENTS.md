# Minesweeper Pool

> Built with Arc Studio - money-powered apps in minutes

This is the **project memory** - what Arc Studio remembers about building this app. It helps future agents (or humans) understand and extend the project.

---

## What This App Does

Onchain Minesweeper game where players pay USDC fees per cell reveal (0.01/0.10/0.50 USDC based on risk tier). All fees accumulate in an onchain pool. The player who completes the board (reveals all 71 safe cells) receives 30% of the total pool. Uses a commit-reveal scheme for the mine layout.

## Deployed Contracts

| Contract | Address | Chain | Explorer |
|---|---|---|---|
| MinesweeperPool | 0xd0ed21e24e3d4fc46eef6d30c0df154285814812 | Arc Testnet | https://explorer.testnet.arc.io/address/0xd0ed21e24e3d4fc46eef6d30c0df154285814812 |

## Contract Notes

- USDC: 0x3600000000000000000000000000000000000000 (Arc Testnet)
- Owner (deployer): 0x5B12Ce46C7194aD57d143bC22847224047b1Ef42
- `startNewGame(bytes32 boardHash, address claimer)` — owner starts a new game. boardHash = keccak256(abi.encodePacked(mineLayout, salt, claimer)) to prevent front-run.
- `revealCell(row, col, feePaid)` — player reveals a cell, pays USDC fee (>= 10000 = 0.01 USDC)
- `claimCompletion(revealedCells, boardSalt, mineLayout)` — authorized claimer completes the game and receives 30% payout
- Pool balance is tracked via USDC.balanceOf(contractAddress)

## Tech Stack

- Frontend: React 18, Vite, TypeScript, Tailwind CSS
- Web3: wagmi v2, viem v2, ConnectKit
- Contracts: Solidity 0.8.28 + Foundry. Sources in `contracts/`, unit tests in `contracts/test/*.t.sol`. Build with `bun run contracts:build` (`forge build`), test with `bun run contracts:test` (`forge test`).
- Wallet: injected (MetaMask, etc.)
- Chain: Arc Testnet (Chain ID: 5042002, imported from `viem/chains`)
- Token: USDC (6 decimals) (Address: 0x3600000000000000000000000000000000000000, Chain: Arc Testnet)
- Toasts: Sonner

## Key Files

- `src/App.tsx` - Main application logic
- `src/components/` - UI components
- `src/config.ts` - wagmi config (chains, connectors, transports)

## To Run

```bash
bun install
bun run dev
```

import { useCallback } from 'react'
import { useReadContract, useSwitchChain, useAccount } from 'wagmi'
import { ConnectKitButton } from 'connectkit'
import { motion } from 'framer-motion'
import { AlertTriangle } from 'lucide-react'
import { Amount, usdcDecimalsFor } from '@/onchain-money'
import { MinesweeperGame } from '@/components/MinesweeperGame'
import { Sidebar } from '@/components/Sidebar'
import { MINESWEEPER_POOL, ARC_TESTNET_CHAIN_ID } from '@/contracts/MinesweeperPool'

export default function App() {
  const { chainId } = useAccount()
  const { switchChain } = useSwitchChain()
  const isWrongChain = chainId !== undefined && chainId !== ARC_TESTNET_CHAIN_ID

  const {
    data: poolRaw,
    refetch: poolRefetch,
  } = useReadContract({
    ...MINESWEEPER_POOL,
    functionName: 'totalPool',
    chainId: ARC_TESTNET_CHAIN_ID,
    query: { refetchInterval: 5000 },
  })

  const poolAmount = poolRaw !== undefined
    ? Amount.fromRaw(poolRaw, usdcDecimalsFor(ARC_TESTNET_CHAIN_ID)).toFixed(2)
    : '0.00'

  const handlePoolUpdate = useCallback(() => {
    void poolRefetch()
  }, [poolRefetch])

  return (
    <div
      className="relative min-h-dvh overflow-hidden"
      style={{ background: 'linear-gradient(180deg, #f9f9fc 0%, #fffcf7 52%, #fbf7f2 100%)' }}
    >
      {/* ambient blobs */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div style={{ position: 'absolute', top: '8%', left: '5%', width: 320, height: 320, borderRadius: '50%', background: 'radial-gradient(circle, rgba(133,177,237,0.18) 0%, transparent 70%)', filter: 'blur(70px)' }} />
        <div style={{ position: 'absolute', bottom: '10%', right: '8%', width: 280, height: 280, borderRadius: '50%', background: 'radial-gradient(circle, rgba(255,205,131,0.16) 0%, transparent 70%)', filter: 'blur(64px)' }} />
        <div style={{ position: 'absolute', top: '40%', right: '25%', width: 200, height: 200, borderRadius: '50%', background: 'radial-gradient(circle, rgba(175,143,244,0.12) 0%, transparent 70%)', filter: 'blur(60px)' }} />
      </div>

      {/* header */}
      <header className="relative z-20 px-6 py-4 flex items-center justify-between border-b" style={{ borderColor: 'var(--border)', background: 'rgba(255,255,255,0.72)', backdropFilter: 'blur(16px)', WebkitBackdropFilter: 'blur(16px)' }}>
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: 'var(--accent)' }}>
            <span className="text-white text-sm" style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 700 }}>M</span>
          </div>
          <div>
            <h1 className="display text-base font-bold" style={{ color: 'var(--ink)', letterSpacing: '-0.02em' }}>
              Minesweeper Pool
            </h1>
            <p className="text-xs" style={{ color: 'var(--muted)' }}>Onchain · Arc Testnet</p>
          </div>
        </div>
        <ConnectKitButton />
      </header>

      {/* wrong chain banner */}
      {isWrongChain && (
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="relative z-20 mx-4 mt-3 rounded-xl px-4 py-3 flex items-center justify-between"
          style={{ background: 'rgba(186,43,76,0.08)', border: '1px solid rgba(186,43,76,0.2)' }}
        >
          <div className="flex items-center gap-2">
            <AlertTriangle size={15} style={{ color: 'var(--danger)' }} />
            <span className="text-xs font-medium" style={{ color: 'var(--danger)' }}>
              Switch to Arc Testnet to play
            </span>
          </div>
          <button
            onClick={() => switchChain({ chainId: ARC_TESTNET_CHAIN_ID })}
            className="rounded-full px-3 py-1 text-xs font-semibold transition-opacity hover:opacity-70"
            style={{ background: 'var(--danger)', color: '#fff' }}
          >
            Switch
          </button>
        </motion.div>
      )}

      {/* main layout */}
      <div className="relative z-10 max-w-5xl mx-auto px-4 py-6 flex flex-col lg:flex-row gap-6">
        {/* game area */}
        <div className="flex-1 min-w-0">
          <MinesweeperGame onPoolUpdate={handlePoolUpdate} poolAmount={poolAmount} />
        </div>

        {/* sidebar */}
        <div className="lg:w-72 w-full flex-shrink-0">
          <Sidebar poolAmount={poolAmount} onPoolUpdate={handlePoolUpdate} poolRefetch={handlePoolUpdate} />
        </div>
      </div>
    </div>
  )
}

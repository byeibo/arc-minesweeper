// Contract address and ABI for MinesweeperPool
// Address will be updated after deployment

export const ARC_TESTNET_CHAIN_ID = 5042002

// Deployed on Arc Testnet — 2026-10-09
export const MINESWEEPER_POOL_ADDRESS = '0xd0ed21e24e3d4fc46eef6d30c0df154285814812' as const

export const MINESWEEPER_POOL_ABI = [
  {
    inputs: [
      { name: 'usdcAddress', type: 'address' },
      { name: 'initialOwner', type: 'address' },
    ],
    stateMutability: 'nonpayable',
    type: 'constructor',
  },
  {
    inputs: [
      { name: 'newBoardHash', type: 'bytes32' },
      { name: 'authorizedClaimer', type: 'address' },
    ],
    name: 'startNewGame',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      { name: 'row', type: 'uint8' },
      { name: 'col', type: 'uint8' },
      { name: 'feePaid', type: 'uint256' },
    ],
    name: 'revealCell',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [
      { name: 'revealedCells', type: 'uint8[]' },
      { name: 'boardSalt', type: 'bytes32' },
      { name: 'mineLayout', type: 'bool[81]' },
    ],
    name: 'claimCompletion',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [],
    name: 'emergencyWithdraw',
    outputs: [],
    stateMutability: 'nonpayable',
    type: 'function',
  },
  {
    inputs: [],
    name: 'totalPool',
    outputs: [{ name: '', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'revealedBitmap',
    outputs: [{ name: '', type: 'uint256[2]' }],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'boardHash',
    outputs: [{ name: '', type: 'bytes32' }],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'currentGameId',
    outputs: [{ name: '', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'isGameActive',
    outputs: [{ name: '', type: 'bool' }],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'authorizedClaimer',
    outputs: [{ name: '', type: 'address' }],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'lastActivityAt',
    outputs: [{ name: '', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'MIN_FEE_SAFE',
    outputs: [{ name: '', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'MIN_FEE_MEDIUM',
    outputs: [{ name: '', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'MIN_FEE_HIGH',
    outputs: [{ name: '', type: 'uint256' }],
    stateMutability: 'view',
    type: 'function',
  },
  {
    inputs: [],
    name: 'usdc',
    outputs: [{ name: '', type: 'address' }],
    stateMutability: 'view',
    type: 'function',
  },
  {
    anonymous: false,
    inputs: [
      { indexed: true, name: 'player', type: 'address' },
      { indexed: false, name: 'row', type: 'uint8' },
      { indexed: false, name: 'col', type: 'uint8' },
      { indexed: false, name: 'fee', type: 'uint256' },
      { indexed: false, name: 'gameId', type: 'uint256' },
    ],
    name: 'CellRevealed',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      { indexed: true, name: 'winner', type: 'address' },
      { indexed: false, name: 'payout', type: 'uint256' },
      { indexed: false, name: 'poolAfter', type: 'uint256' },
      { indexed: false, name: 'gameId', type: 'uint256' },
    ],
    name: 'GameCompleted',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      { indexed: false, name: 'gameId', type: 'uint256' },
      { indexed: false, name: 'boardHash', type: 'bytes32' },
    ],
    name: 'NewGameStarted',
    type: 'event',
  },
  {
    anonymous: false,
    inputs: [
      { indexed: true, name: 'player', type: 'address' },
      { indexed: false, name: 'amount', type: 'uint256' },
      { indexed: false, name: 'newTotal', type: 'uint256' },
    ],
    name: 'PoolContribution',
    type: 'event',
  },
] as const

export const MINESWEEPER_POOL = {
  address: MINESWEEPER_POOL_ADDRESS,
  abi: MINESWEEPER_POOL_ABI,
} as const

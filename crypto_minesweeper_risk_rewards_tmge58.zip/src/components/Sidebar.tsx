import { useReadContract } from 'wagmi'
import { motion } from 'framer-motion'
import { ConnectKitButton } from 'connectkit'
import { Layers, Coins, Users } from 'lucide-react'
import { TokenUSDC } from '@web3icons/react'

import { MINESWEEPER_POOL, ARC_TESTNET_CHAIN_ID } from '@/contracts/MinesweeperPool'
import { buildAddressExplorerUrl } from '@/onchain-facts'

interface Props {
  poolAmount: string
  onPoolUpdate: () => void
  poolRefetch: () => void // wrapped void callback
}

export function Sidebar({ poolAmount }: Props) {
  const { data: gameId } = useReadContract({
    ...MINESWEEPER_POOL,
    functionName: 'currentGameId',
    chainId: ARC_TESTNET_CHAIN_ID,
    query: { refetchInterval: 6000 },
  })

  const { data: isGameActive } = useReadContract({
    ...MINESWEEPER_POOL,
    functionName: 'isGameActive',
    chainId: ARC_TESTNET_CHAIN_ID,
    query: { refetchInterval: 4000 },
  })

  const { data: bitmap } = useReadContract({
    ...MINESWEEPER_POOL,
    functionName: 'revealedBitmap',
    chainId: ARC_TESTNET_CHAIN_ID,
    query: { refetchInterval: 4000 },
  })

  const revealedCount = bitmap
    ? countBits((bitmap as [bigint, bigint])[0], 64) + countBits((bitmap as [bigint, bigint])[1], 17)
    : 0

  const winnerPayout = poolAmount
    ? Math.floor(parseFloat(poolAmount) * 0.3 * 100) / 100
    : 0

  return (
    <div className="flex flex-col gap-4">
      {/* wallet */}
      <div
        className="rounded-2xl p-4"
        style={{
          background: 'rgba(255,255,255,0.64)',
          backdropFilter: 'blur(24px) saturate(180%)',
          WebkitBackdropFilter: 'blur(24px) saturate(180%)',
          border: '1px solid rgba(255,255,255,0.68)',
          boxShadow: '0 8px 32px rgba(18,45,69,0.08)',
        }}
      >
        <p className="text-xs font-semibold mb-3" style={{ color: 'var(--muted)', letterSpacing: '0.08em' }}>
          WALLET
        </p>
        <ConnectKitButton />
      </div>

      {/* pool card */}
      <div
        className="rounded-2xl p-5 relative overflow-hidden"
        style={{
          background: 'rgba(255,255,255,0.64)',
          backdropFilter: 'blur(24px) saturate(180%)',
          WebkitBackdropFilter: 'blur(24px) saturate(180%)',
          border: '1px solid rgba(255,255,255,0.68)',
          boxShadow: '0 8px 32px rgba(18,45,69,0.08)',
        }}
      >
        {/* spectral accent strip */}
        <div
          className="absolute top-0 left-0 right-0 h-0.5 rounded-t-2xl"
          style={{ background: 'linear-gradient(90deg, #5fbeff, #af8ff4, #f05c6b, #ffcd83, #7ef1b3)' }}
        />

        <div className="flex items-center gap-2 mb-1">
          <TokenUSDC variant="branded" size={18} />
          <p className="text-xs font-semibold" style={{ color: 'var(--muted)', letterSpacing: '0.08em' }}>
            TOTAL POOL
          </p>
        </div>
        <motion.p
          key={poolAmount}
          initial={{ opacity: 0.5, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          className="display text-3xl font-bold tabular-nums"
          style={{ color: 'var(--ink)', letterSpacing: '-0.03em' }}
        >
          {poolAmount}
        </motion.p>
        <p className="text-xs mt-0.5 tabular-nums" style={{ color: 'var(--muted)' }}>USDC on Arc Testnet</p>

        <div className="mt-4 rounded-xl p-3" style={{ background: 'rgba(255,255,255,0.46)', border: '1px solid rgba(255,255,255,0.56)' }}>
          <div className="flex items-center justify-between">
            <span className="text-xs" style={{ color: 'var(--muted)' }}>Winner receives</span>
            <span className="text-sm font-bold tabular-nums" style={{ color: 'var(--success)' }}>
              {winnerPayout.toFixed(2)} USDC
            </span>
          </div>
          <p className="text-xs mt-0.5" style={{ color: 'var(--subtle)' }}>30% of pool on completion</p>
        </div>
      </div>

      {/* game stats */}
      <div
        className="rounded-2xl p-4"
        style={{
          background: 'rgba(255,255,255,0.64)',
          backdropFilter: 'blur(24px) saturate(180%)',
          WebkitBackdropFilter: 'blur(24px) saturate(180%)',
          border: '1px solid rgba(255,255,255,0.68)',
          boxShadow: '0 8px 32px rgba(18,45,69,0.08)',
        }}
      >
        <p className="text-xs font-semibold mb-3" style={{ color: 'var(--muted)', letterSpacing: '0.08em' }}>
          GAME STATUS
        </p>
        <div className="space-y-2.5">
          <StatRow
            icon={<Layers size={14} style={{ color: 'var(--accent)' }} />}
            label="Game ID"
            value={gameId !== undefined ? `#${gameId.toString()}` : '—'}
          />
          <StatRow
            icon={<Coins size={14} style={{ color: 'var(--accent)' }} />}
            label="Status"
            value={
              isGameActive === undefined ? '...' : isGameActive ? 'Active' : 'Inactive'
            }
            valueColor={isGameActive ? 'var(--success)' : 'var(--danger)'}
          />
          <StatRow
            icon={<Users size={14} style={{ color: 'var(--accent)' }} />}
            label="Cells revealed"
            value={`${revealedCount}/71`}
          />
        </div>
      </div>

      {/* contract link */}
      <a
        href={buildAddressExplorerUrl(ARC_TESTNET_CHAIN_ID, MINESWEEPER_POOL.address)}
        target="_blank"
        rel="noopener noreferrer"
        className="text-xs text-center hover:underline"
        style={{ color: 'var(--subtle)' }}
      >
        View contract on explorer
      </a>

      {/* how to play */}
      <div
        className="rounded-2xl p-4"
        style={{
          background: 'rgba(255,255,255,0.46)',
          border: '1px solid rgba(255,255,255,0.56)',
        }}
      >
        <p className="text-xs font-semibold mb-2" style={{ color: 'var(--muted)', letterSpacing: '0.08em' }}>
          HOW TO PLAY
        </p>
        <ul className="space-y-1.5">
          {[
            'Connect your wallet to Arc Testnet',
            'Click a cell to reveal it — each reveal costs USDC based on risk',
            'Right-click to flag suspected mines',
            'Reveal all 71 safe cells to win 30% of the pool',
            'Hit a mine = game over (local only, your USDC contributions stay in the pool)',
          ].map((tip, i) => (
            <li key={i} className="flex gap-2 text-xs" style={{ color: 'var(--ink-2)' }}>
              <span style={{ color: 'var(--subtle)', minWidth: 14 }}>{i + 1}.</span>
              {tip}
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}

function StatRow({ icon, label, value, valueColor }: { icon: React.ReactNode; label: string; value: string; valueColor?: string }) {
  return (
    <div className="flex items-center justify-between">
      <div className="flex items-center gap-2">
        {icon}
        <span className="text-xs" style={{ color: 'var(--muted)' }}>{label}</span>
      </div>
      <span className="text-xs font-semibold tabular-nums" style={{ color: valueColor ?? 'var(--ink)' }}>
        {value}
      </span>
    </div>
  )
}

function countBits(n: bigint, maxBits: number): number {
  let count = 0
  for (let i = 0; i < maxBits; i++) {
    if ((n & (BigInt(1) << BigInt(i))) !== BigInt(0)) count++
  }
  return count
}

import { useState, useCallback, useRef, useEffect } from 'react'
import { useAccount, useWriteContract, useWaitForTransactionReceipt, useReadContract } from 'wagmi'
import { erc20Abi } from 'viem'
import { motion, AnimatePresence } from 'framer-motion'
import { toast } from 'sonner'
import { getUsdc, buildTxExplorerUrl } from '@/onchain-facts'
import { parseAmount, Amount, usdcDecimalsFor } from '@/onchain-money'
import { parseOnchainError } from '@/utils/errors'
import { MINESWEEPER_POOL, ARC_TESTNET_CHAIN_ID } from '@/contracts/MinesweeperPool'
import type { GameState, CellState } from '@/types/game'
import { generateBoard, computeAdjacency, computeRiskTier, floodReveal, type RiskTier } from '@/utils/minesweeper'
import { Flag, Bomb, RefreshCw, Trophy, Info } from 'lucide-react'

const USDC = getUsdc(ARC_TESTNET_CHAIN_ID)!

const TIER_FEE: Record<RiskTier, bigint> = {
  safe: parseAmount(ARC_TESTNET_CHAIN_ID, '0.01').raw,
  medium: parseAmount(ARC_TESTNET_CHAIN_ID, '0.10').raw,
  high: parseAmount(ARC_TESTNET_CHAIN_ID, '0.50').raw,
}

const TIER_LABEL: Record<RiskTier, string> = {
  safe: '0.01 USDC',
  medium: '0.10 USDC',
  high: '0.50 USDC',
}

const TIER_COLOR: Record<RiskTier, string> = {
  safe: '#1a8047',
  medium: '#c87400',
  high: '#ba2b4c',
}

const ADJ_COLORS = ['', '#1a6fc4', '#1a8047', '#ba2b4c', '#5a1a8a', '#8a3010', '#1a9090', '#111', '#555']

function makeBoard(): GameState {
  const mines = generateBoard(9, 9, 10)
  return { mines, adjacency: computeAdjacency(mines, 9, 9) }
}

function emptyCells(): CellState[] {
  return Array.from({ length: 81 }, () => ({ revealed: false, flagged: false }))
}

interface Props {
  onPoolUpdate: () => void
  poolAmount: string
}

export function MinesweeperGame({ onPoolUpdate, poolAmount }: Props) {
  const { address, chainId } = useAccount()

  // ─── local game state (always visible) ───
  const [board, setBoard] = useState<GameState>(makeBoard)
  const [cells, setCells] = useState<CellState[]>(emptyCells)
  const [gameOver, setGameOver] = useState<'win' | 'lose' | null>(null)
  const [selectedCell, setSelectedCell] = useState<number | null>(null)
  const [lastTxHash, setLastTxHash] = useState<`0x${string}` | undefined>()

  // approve-then-reveal queue
  const pendingRevealRef = useRef<{ cellIndex: number; fee: bigint } | null>(null)

  // ─── onchain reads ───
  const { data: isGameActive } = useReadContract({
    ...MINESWEEPER_POOL,
    functionName: 'isGameActive',
    chainId: ARC_TESTNET_CHAIN_ID,
    query: { refetchInterval: 4000 },
  })

  const { data: revealedBitmap } = useReadContract({
    ...MINESWEEPER_POOL,
    functionName: 'revealedBitmap',
    chainId: ARC_TESTNET_CHAIN_ID,
    query: { refetchInterval: 4000 },
  })

  const { data: userAllowance, refetch: refetchAllowance } = useReadContract({
    address: USDC.address as `0x${string}`,
    abi: erc20Abi,
    functionName: 'allowance',
    args: address ? [address, MINESWEEPER_POOL.address] : undefined,
    chainId: ARC_TESTNET_CHAIN_ID,
    query: { enabled: !!address },
  })

  const { data: userBalance } = useReadContract({
    address: USDC.address as `0x${string}`,
    abi: erc20Abi,
    functionName: 'balanceOf',
    args: address ? [address] : undefined,
    chainId: ARC_TESTNET_CHAIN_ID,
    query: { enabled: !!address, refetchInterval: 5000 },
  })

  // ─── write hooks ───
  const { writeContract, isPending: isWritePending } = useWriteContract({
    mutation: {
      onSuccess(hash) { setLastTxHash(hash) },
      onError(err) {
        toast.error(parseOnchainError(err))
        pendingRevealRef.current = null
        setSelectedCell(null)
      },
    },
  })

  const { isLoading: isConfirming, isSuccess: txSuccess } =
    useWaitForTransactionReceipt({ hash: lastTxHash })

  // After approval confirms: fire the pending reveal
  useEffect(() => {
    if (!txSuccess || !lastTxHash) return
    void refetchAllowance()
    onPoolUpdate()
    const pending = pendingRevealRef.current
    if (pending) {
      pendingRevealRef.current = null
      const row = Math.floor(pending.cellIndex / 9)
      const col = pending.cellIndex % 9
      writeContract({
        ...MINESWEEPER_POOL,
        functionName: 'revealCell',
        args: [row, col, pending.fee],
      })
    }
  }, [txSuccess, lastTxHash, refetchAllowance, onPoolUpdate, writeContract])

  // Sync onchain bitmap into local cell state
  const prevBitmap = useRef<readonly [bigint, bigint] | null>(null)
  useEffect(() => {
    if (!revealedBitmap) return
    const bm = revealedBitmap as [bigint, bigint]
    if (prevBitmap.current?.[0] === bm[0] && prevBitmap.current?.[1] === bm[1]) return
    prevBitmap.current = bm
    const [lo, hi] = bm
    setCells(prev =>
      prev.map((cell, idx) => {
        const bit =
          idx < 64
            ? (lo & (BigInt(1) << BigInt(idx))) !== BigInt(0)
            : (hi & (BigInt(1) << BigInt(idx - 64))) !== BigInt(0)
        return bit ? { ...cell, revealed: true } : cell
      }),
    )
  }, [revealedBitmap])

  const isWrongChain = !!chainId && chainId !== ARC_TESTNET_CHAIN_ID
  const isBusy = isWritePending || isConfirming
  const canPlay = !!address && !isWrongChain && isGameActive === true && !gameOver

  const getRiskTier = useCallback(
    (idx: number): RiskTier => computeRiskTier(idx, board.mines, board.adjacency, 9),
    [board],
  )

  // ─── New Game ─── randomises mines every time
  const handleStartNew = useCallback(() => {
    setBoard(makeBoard())
    setCells(emptyCells())
    setGameOver(null)
    setSelectedCell(null)
    setLastTxHash(undefined)
    pendingRevealRef.current = null
    prevBitmap.current = null
  }, [])

  // ─── Reveal ───
  const handleReveal = useCallback((cellIndex: number) => {
    if (!canPlay || isBusy) return
    const cell = cells[cellIndex]
    if (cell.revealed || cell.flagged) return

    // Mine hit — local only, no tx
    if (board.mines[cellIndex]) {
      setCells(prev => prev.map((c, i) => board.mines[i] ? { ...c, revealed: true } : c))
      setGameOver('lose')
      toast.error('Mayına bastın! Oyun bitti.')
      return
    }

    const tier = getRiskTier(cellIndex)
    const fee = TIER_FEE[tier]

    // Needs approval first?
    if (!userAllowance || userAllowance < fee) {
      pendingRevealRef.current = { cellIndex, fee }
      writeContract({
        address: USDC.address as `0x${string}`,
        abi: erc20Abi,
        functionName: 'approve',
        args: [MINESWEEPER_POOL.address, BigInt('0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff')],
      })
      toast.info('USDC harcama izni veriliyor…')
      return
    }

    // Flood fill zero-adjacency cells
    const toReveal =
      board.adjacency[cellIndex] === 0
        ? floodReveal(cellIndex, board.mines, board.adjacency, cells, 9)
        : [cellIndex]

    setSelectedCell(cellIndex)

    // Optimistic local reveal
    setCells(prev => prev.map((c, i) => toReveal.includes(i) ? { ...c, revealed: true } : c))

    const row = Math.floor(cellIndex / 9)
    const col = cellIndex % 9
    writeContract({ ...MINESWEEPER_POOL, functionName: 'revealCell', args: [row, col, fee] })
    toast.info(`Açılıyor — ${TIER_LABEL[tier]}`)
  }, [canPlay, isBusy, cells, board, getRiskTier, userAllowance, writeContract])

  // ─── Flag ───
  const handleFlag = useCallback((e: React.MouseEvent, cellIndex: number) => {
    e.preventDefault()
    if (gameOver) return
    const cell = cells[cellIndex]
    if (cell.revealed) return
    setCells(prev => prev.map((c, i) => i === cellIndex ? { ...c, flagged: !c.flagged } : c))
  }, [cells, gameOver])

  // ─── Derived stats ───
  const revealedSafe = cells.filter((c, i) => c.revealed && !board.mines[i]).length
  const safeCount = board.mines.filter(m => !m).length
  const progress = safeCount > 0 ? Math.round((revealedSafe / safeCount) * 100) : 0
  const flagCount = cells.filter(c => c.flagged).length
  const mineCount = board.mines.filter(Boolean).length

  return (
    <div className="flex flex-col gap-4">
      {/* ── top status bar ── */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          {/* Mine counter */}
          <div className="flex items-center gap-1.5 rounded-xl px-3 py-1.5"
            style={{ background: 'rgba(186,43,76,0.08)', border: '1px solid rgba(186,43,76,0.15)' }}>
            <Bomb size={13} style={{ color: '#ba2b4c' }} />
            <span className="text-sm font-bold tabular-nums mono" style={{ color: '#ba2b4c' }}>
              {String(mineCount - flagCount).padStart(2, '0')}
            </span>
          </div>

          {/* Progress */}
          <div className="flex items-center gap-2">
            <div className="h-1.5 w-24 rounded-full overflow-hidden" style={{ background: 'var(--surface-muted)' }}>
              <motion.div
                className="h-full rounded-full"
                style={{ background: 'var(--success)' }}
                animate={{ width: `${progress}%` }}
                transition={{ type: 'spring', stiffness: 120, damping: 20 }}
              />
            </div>
            <span className="text-xs font-semibold tabular-nums" style={{ color: 'var(--ink-2)' }}>
              {revealedSafe}/{safeCount}
            </span>
          </div>
        </div>

        {/* New Game button */}
        <button
          onClick={handleStartNew}
          className="flex items-center gap-1.5 rounded-xl px-3 py-1.5 text-xs font-semibold transition-all hover:opacity-80 active:scale-95"
          style={{ background: 'var(--accent)', color: '#fff' }}
        >
          <RefreshCw size={12} />
          Yeni Oyun
        </button>
      </div>

      {/* ── onchain status banner ── */}
      <AnimatePresence>
        {isGameActive === false && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="overflow-hidden"
          >
            <div className="rounded-xl px-4 py-2.5 flex items-center gap-2"
              style={{ background: 'rgba(172,198,233,0.15)', border: '1px solid rgba(172,198,233,0.35)' }}>
              <Info size={13} style={{ color: 'var(--accent-hover)', flexShrink: 0 }} />
              <p className="text-xs" style={{ color: 'var(--ink-2)' }}>
                Zincirde aktif oyun yok — sözleşme sahibi <code className="mono text-xs px-1 rounded"
                  style={{ background: 'rgba(18,45,69,0.07)' }}>startNewGame()</code> çağırmalı.
                Tahtayı ücretsiz keşfedebilirsin.
              </p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── game grid ── always visible ── */}
      <div
        className="rounded-2xl p-3 select-none"
        style={{
          background: 'rgba(255,255,255,0.72)',
          backdropFilter: 'blur(24px) saturate(180%)',
          WebkitBackdropFilter: 'blur(24px) saturate(180%)',
          border: '1px solid rgba(255,255,255,0.75)',
          boxShadow: '0 8px 40px rgba(18,45,69,0.10), inset 0 1px 0 rgba(255,255,255,0.6)',
        }}
      >
        <div
          style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(9, 1fr)',
            gap: '4px',
            width: '100%',
          }}
        >
          {cells.map((cell, idx) => (
            <CellButton
              key={idx}
              cell={cell}
              tier={getRiskTier(idx)}
              adj={board.adjacency[idx]}
              isMine={board.mines[idx]}
              isSelected={selectedCell === idx}
              isBusy={isBusy && !cell.revealed}
              gameOver={gameOver}
              canPlay={canPlay}
              onClick={() => handleReveal(idx)}
              onContextMenu={e => handleFlag(e, idx)}
            />
          ))}
        </div>
      </div>

      {/* ── game result banner ── */}
      <AnimatePresence>
        {gameOver && (
          <motion.div
            initial={{ opacity: 0, scale: 0.97, y: 6 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97, y: -6 }}
            className="rounded-2xl p-4 flex items-center justify-between"
            style={{
              background: gameOver === 'win' ? 'rgba(26,128,71,0.08)' : 'rgba(186,43,76,0.08)',
              border: `1px solid ${gameOver === 'win' ? 'rgba(26,128,71,0.25)' : 'rgba(186,43,76,0.25)'}`,
            }}
          >
            <div className="flex items-center gap-3">
              {gameOver === 'win'
                ? <Trophy size={22} style={{ color: 'var(--success)' }} />
                : <Bomb size={22} style={{ color: 'var(--danger)' }} />}
              <div>
                <p className="text-sm font-bold" style={{ color: gameOver === 'win' ? 'var(--success)' : 'var(--danger)' }}>
                  {gameOver === 'win' ? 'Tahta temizlendi!' : 'Mayına bastın!'}
                </p>
                {gameOver === 'win' && (
                  <p className="text-xs mt-0.5 tabular-nums" style={{ color: 'var(--muted)' }}>
                    Ödül: {(Math.floor(parseFloat(poolAmount) * 0.30 * 100) / 100).toFixed(2)} USDC (havuzun %30'u)
                  </p>
                )}
              </div>
            </div>
            <button
              onClick={handleStartNew}
              className="flex items-center gap-1.5 rounded-xl px-3 py-2 text-xs font-semibold transition-all hover:opacity-80 active:scale-95"
              style={{ background: 'var(--accent)', color: '#fff' }}
            >
              <RefreshCw size={12} />
              Yeniden
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── legend + balance ── */}
      <div className="flex flex-wrap items-center gap-x-4 gap-y-2 px-1">
        {(['safe', 'medium', 'high'] as RiskTier[]).map(tier => (
          <div key={tier} className="flex items-center gap-1.5">
            <div className="w-2.5 h-2.5 rounded-sm" style={{ background: TIER_COLOR[tier] }} />
            <span className="text-xs" style={{ color: 'var(--muted)' }}>
              {tier === 'safe' ? 'Güvenli' : tier === 'medium' ? 'Orta' : 'Yüksek'} — {TIER_LABEL[tier]}
            </span>
          </div>
        ))}
      </div>

      <div className="flex flex-wrap items-center justify-between gap-2 px-1">
        {address && userBalance !== undefined && (
          <span className="text-xs tabular-nums" style={{ color: 'var(--subtle)' }}>
            Bakiye: <strong className="tabular-nums" style={{ color: 'var(--ink-2)' }}>
              {Amount.fromRaw(userBalance, usdcDecimalsFor(ARC_TESTNET_CHAIN_ID)).toFixed(2)} USDC
            </strong>
          </span>
        )}

        {lastTxHash && txSuccess && (
          <a
            href={buildTxExplorerUrl(ARC_TESTNET_CHAIN_ID, lastTxHash)}
            target="_blank"
            rel="noopener noreferrer"
            className="text-xs hover:underline tabular-nums"
            style={{ color: 'var(--accent-hover)' }}
          >
            Son işlemi gör
          </a>
        )}
      </div>
    </div>
  )
}

// ─── Cell Button ───────────────────────────────────────────────────────────────

interface CellButtonProps {
  cell: CellState
  tier: RiskTier
  adj: number
  isMine: boolean
  isSelected: boolean
  isBusy: boolean
  gameOver: 'win' | 'lose' | null
  canPlay: boolean
  onClick: () => void
  onContextMenu: (e: React.MouseEvent) => void
}

function CellButton({
  cell, tier, adj, isMine, isSelected, isBusy, gameOver, canPlay, onClick, onContextMenu,
}: CellButtonProps) {
  const { revealed, flagged } = cell

  const bgColor = revealed
    ? isMine
      ? 'rgba(186,43,76,0.15)'
      : 'rgba(248,249,252,0.95)'
    : isSelected
    ? 'rgba(172,198,233,0.40)'
    : 'rgba(236,237,246,0.85)'

  const borderColor = revealed
    ? isMine
      ? 'rgba(186,43,76,0.35)'
      : 'rgba(200,205,220,0.5)'
    : flagged
    ? 'rgba(200,116,0,0.45)'
    : `${TIER_COLOR[tier]}4a`

  const cursor =
    revealed || flagged || gameOver
      ? 'default'
      : isBusy
      ? 'wait'
      : canPlay
      ? 'pointer'
      : 'default'

  return (
    <motion.button
      whileTap={!revealed && !flagged && !gameOver && canPlay ? { scale: 0.88 } : undefined}
      onClick={!revealed && !flagged && !gameOver ? onClick : undefined}
      onContextMenu={!revealed && !gameOver ? onContextMenu : undefined}
      style={{
        aspectRatio: '1 / 1',
        borderRadius: '5px',
        background: bgColor,
        border: `1.5px solid ${borderColor}`,
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        cursor,
        transition: 'background 0.12s, border-color 0.12s',
        minWidth: 0,
        minHeight: 0,
        padding: 0,
        boxShadow: revealed ? 'none' : 'inset 0 1px 0 rgba(255,255,255,0.8)',
      }}
      aria-label={revealed ? (isMine ? 'mine' : String(adj)) : flagged ? 'flagged' : 'unrevealed'}
    >
      {revealed && isMine && <Bomb size={14} style={{ color: '#ba2b4c' }} />}
      {revealed && !isMine && adj > 0 && (
        <span
          style={{
            fontSize: '11px',
            fontWeight: 700,
            fontFamily: "'JetBrains Mono', monospace",
            color: ADJ_COLORS[adj],
            lineHeight: 1,
          }}
        >
          {adj}
        </span>
      )}
      {!revealed && flagged && <Flag size={11} style={{ color: '#c87400' }} />}
      {!revealed && !flagged && (
        <div
          style={{
            width: '7px',
            height: '7px',
            borderRadius: '50%',
            background: TIER_COLOR[tier],
            opacity: 0.55,
          }}
        />
      )}
    </motion.button>
  )
}

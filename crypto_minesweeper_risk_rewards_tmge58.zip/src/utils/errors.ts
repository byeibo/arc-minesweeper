export function parseOnchainError(error: unknown): string {
  if (!error) return 'Something went wrong.'
  const msg = (error as { message?: string })?.message?.toLowerCase() ?? ''

  if (msg.includes('user rejected') || (error as { code?: number })?.code === 4001) {
    return 'Transaction cancelled.'
  }
  if (msg.includes('insufficient funds') || msg.includes('exceeds balance')) {
    return 'Insufficient USDC balance. Use "Get test USDC" in the sidebar.'
  }
  if (msg.includes('reverted')) {
    const match = msg.match(/reason="([^"]+)"/)
    return match ? `Transaction failed: ${match[1]}` : 'Transaction reverted. Please try again.'
  }
  if (msg.includes('network') || msg.includes('timeout')) {
    return 'Network issue. Check your connection and retry.'
  }
  return 'Something went wrong. Please try again.'
}

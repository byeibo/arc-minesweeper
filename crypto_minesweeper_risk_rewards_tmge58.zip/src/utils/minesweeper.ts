import type { CellState } from '@/types/game'

export const RISK_TIER = {
  safe: 'safe',
  medium: 'medium',
  high: 'high',
} as const

export type RiskTier = (typeof RISK_TIER)[keyof typeof RISK_TIER]

/** Generate a flat 81-element boolean array of mine positions using Fisher-Yates. */
export function generateBoard(rows: number, cols: number, mineCount: number): boolean[] {
  const total = rows * cols
  const mines: boolean[] = Array.from({ length: total }, () => false)
  const indices = Array.from({ length: total }, (_, i) => i)

  // Fisher-Yates shuffle
  for (let i = total - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[indices[i], indices[j]] = [indices[j], indices[i]]
  }

  for (let i = 0; i < mineCount; i++) {
    mines[indices[i]] = true
  }

  return mines
}

/** Compute adjacency counts for each cell (number of neighboring mines). */
export function computeAdjacency(mines: boolean[], rows: number, cols: number): number[] {
  const adj: number[] = Array.from({ length: rows * cols }, () => 0)
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      if (mines[r * cols + c]) continue
      let count = 0
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          if (dr === 0 && dc === 0) continue
          const nr = r + dr
          const nc = c + dc
          if (nr >= 0 && nr < rows && nc >= 0 && nc < cols && mines[nr * cols + nc]) {
            count++
          }
        }
      }
      adj[r * cols + c] = count
    }
  }
  return adj
}

/** Determine the risk tier for a cell based on adjacency to mines. */
export function computeRiskTier(
  cellIndex: number,
  mines: boolean[],
  adjacency: number[],
  _cols: number,
): RiskTier {
  if (mines[cellIndex]) return RISK_TIER.high
  const adj = adjacency[cellIndex]
  if (adj === 0) return RISK_TIER.safe
  if (adj <= 2) return RISK_TIER.medium
  return RISK_TIER.high
}

/** Flood fill unrevealed cells from a zero-adjacency cell. Returns list of cell indices to reveal. */
export function floodReveal(
  startIndex: number,
  mines: boolean[],
  adjacency: number[],
  cells: CellState[],
  cols: number,
): number[] {
  const rows = Math.ceil(mines.length / cols)
  const toReveal: number[] = []
  const visited = new Set<number>()
  const queue: number[] = [startIndex]

  while (queue.length > 0) {
    const idx = queue.shift()!
    if (visited.has(idx)) continue
    visited.add(idx)

    if (cells[idx].revealed || cells[idx].flagged || mines[idx]) continue
    toReveal.push(idx)

    if (adjacency[idx] === 0) {
      const r = Math.floor(idx / cols)
      const c = idx % cols
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          if (dr === 0 && dc === 0) continue
          const nr = r + dr
          const nc = c + dc
          if (nr >= 0 && nr < rows && nc >= 0 && nc < cols) {
            const ni = nr * cols + nc
            if (!visited.has(ni)) queue.push(ni)
          }
        }
      }
    }
  }

  return toReveal
}

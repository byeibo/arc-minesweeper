export interface CellState {
  revealed: boolean
  flagged: boolean
}

export interface GameState {
  mines: boolean[]
  adjacency: number[]
}

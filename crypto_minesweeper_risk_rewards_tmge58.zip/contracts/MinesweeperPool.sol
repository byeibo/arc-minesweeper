// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import {Ownable} from "@openzeppelin/contracts/access/Ownable.sol";
import {ReentrancyGuard} from "@openzeppelin/contracts/utils/ReentrancyGuard.sol";
import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import {SafeERC20} from "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";

contract MinesweeperPool is Ownable, ReentrancyGuard {
    using SafeERC20 for IERC20;

    uint8 private constant GRID_SIZE = 9;
    uint8 private constant TOTAL_CELLS = 81;
    uint8 private constant TOTAL_MINES = 10;
    uint8 private constant TOTAL_SAFE_CELLS = TOTAL_CELLS - TOTAL_MINES;

    /// @notice Minimum fee per reveal (any cell). Frontend enforces higher tiers per risk level.
    uint256 public constant MIN_FEE_SAFE = 10_000; // 0.01 USDC (6 decimals)
    /// @notice Frontend-only reference for medium-risk cells (0.10 USDC). Not enforced on-chain.
    uint256 public constant MIN_FEE_MEDIUM = 100_000;
    /// @notice Frontend-only reference for high-risk cells (0.50 USDC). Not enforced on-chain.
    uint256 public constant MIN_FEE_HIGH = 500_000;

    IERC20 public immutable usdc;

    uint256[2] private _revealedBits;
    bytes32 private _boardHash;
    uint256 private _currentGameId;
    bool private _gameActive;
    uint256 private _lastActivityAt;
    /// @notice Address authorized to call claimCompletion for the current game. Set by owner when starting a game.
    address private _authorizedClaimer;

    event CellRevealed(address indexed player, uint8 row, uint8 col, uint256 fee, uint256 gameId);
    event GameCompleted(address indexed winner, uint256 payout, uint256 poolAfter, uint256 gameId);
    event NewGameStarted(uint256 gameId, bytes32 boardHash);
    event PoolContribution(address indexed player, uint256 amount, uint256 newTotal);

    constructor(address usdcAddress, address initialOwner) Ownable(initialOwner) {
        require(usdcAddress != address(0), "USDC address is zero");
        usdc = IERC20(usdcAddress);
        _lastActivityAt = block.timestamp;
    }

    /// @notice Start a new game. The board hash must commit to the mine layout, salt, AND authorizedClaimer
    ///         to prevent front-run payout theft: boardHash = keccak256(abi.encodePacked(mineLayout, salt, claimer)).
    function startNewGame(bytes32 newBoardHash, address claimer) external onlyOwner {
        require(!_gameActive, "Game is active");
        require(newBoardHash != bytes32(0), "Board hash is zero");
        require(claimer != address(0), "Claimer is zero");

        _revealedBits[0] = 0;
        _revealedBits[1] = 0;

        _currentGameId += 1;
        _boardHash = newBoardHash;
        _authorizedClaimer = claimer;
        _gameActive = true;
        _lastActivityAt = block.timestamp;

        emit NewGameStarted(_currentGameId, newBoardHash);
    }

    function revealCell(uint8 row, uint8 col, uint256 feePaid) external nonReentrant {
        require(_gameActive, "Game is not active");
        require(row < GRID_SIZE && col < GRID_SIZE, "Cell out of bounds");
        require(feePaid >= MIN_FEE_SAFE, "Fee below minimum");

        uint8 cellIndex = row * GRID_SIZE + col;
        require(!_isCellRevealed(cellIndex), "Cell already revealed");

        _setCellRevealed(cellIndex);
        _lastActivityAt = block.timestamp;

        usdc.safeTransferFrom(msg.sender, address(this), feePaid);

        emit CellRevealed(msg.sender, row, col, feePaid, _currentGameId);
        emit PoolContribution(msg.sender, feePaid, usdc.balanceOf(address(this)));
    }

    /// @notice Claim the completion payout. Only the address set by owner in startNewGame may call.
    ///         Provide boardSalt and mineLayout whose hash matches: keccak256(abi.encodePacked(mineLayout, boardSalt, msg.sender)).
    function claimCompletion(
        uint8[] calldata revealedCells,
        bytes32 boardSalt,
        bool[81] calldata mineLayout
    ) external nonReentrant {
        require(_gameActive, "Game is not active");
        require(_boardHash != bytes32(0), "Board hash not set");
        require(msg.sender == _authorizedClaimer, "Not authorized claimer");
        require(revealedCells.length == TOTAL_SAFE_CELLS, "Invalid revealed cells length");
        require(
            keccak256(abi.encodePacked(mineLayout, boardSalt, msg.sender)) == _boardHash,
            "Board reveal does not match commitment"
        );

        uint256 mineCount;
        uint256[2] memory submittedSafeBits;

        for (uint256 i = 0; i < revealedCells.length; i++) {
            uint8 cellIndex = revealedCells[i];
            require(cellIndex < TOTAL_CELLS, "Invalid cell index");
            require(!mineLayout[cellIndex], "Submitted mine cell");
            require(!_memBitGet(submittedSafeBits, cellIndex), "Duplicate revealed cell");
            _memBitSet(submittedSafeBits, cellIndex);
        }

        for (uint8 idx = 0; idx < TOTAL_CELLS; idx++) {
            if (mineLayout[idx]) {
                mineCount += 1;
            } else {
                require(_memBitGet(submittedSafeBits, idx), "Missing safe cell in submission");
                require(_isCellRevealed(idx), "Safe cell not revealed onchain");
            }
        }

        require(mineCount == TOTAL_MINES, "Mine count must be 10");

        uint256 pool = usdc.balanceOf(address(this));
        uint256 payout = (pool * 30) / 100;
        uint256 poolAfter = pool - payout;

        _gameActive = false;
        _boardHash = bytes32(0);
        _lastActivityAt = block.timestamp;

        if (payout > 0) {
            usdc.safeTransfer(msg.sender, payout);
        }

        emit GameCompleted(msg.sender, payout, poolAfter, _currentGameId);
    }

    function emergencyWithdraw() external onlyOwner nonReentrant {
        if (_gameActive) {
            require(block.timestamp >= _lastActivityAt + 7 days, "Game active and not inactive");
        }

        uint256 amount = usdc.balanceOf(address(this));
        require(amount > 0, "No funds");

        _gameActive = false;
        _boardHash = bytes32(0);
        _lastActivityAt = block.timestamp;

        usdc.safeTransfer(owner(), amount);
    }

    function totalPool() external view returns (uint256) {
        return usdc.balanceOf(address(this));
    }

    function revealedBitmap() external view returns (uint256[2] memory) {
        return _revealedBits;
    }

    function boardHash() external view returns (bytes32) {
        return _boardHash;
    }

    function currentGameId() external view returns (uint256) {
        return _currentGameId;
    }

    function isGameActive() external view returns (bool) {
        return _gameActive;
    }

    function authorizedClaimer() external view returns (address) {
        return _authorizedClaimer;
    }

    function lastActivityAt() external view returns (uint256) {
        return _lastActivityAt;
    }

    function _isCellRevealed(uint8 cellIndex) internal view returns (bool) {
        if (cellIndex < 64) {
            return (_revealedBits[0] & (uint256(1) << cellIndex)) != 0;
        }
        return (_revealedBits[1] & (uint256(1) << (cellIndex - 64))) != 0;
    }

    function _setCellRevealed(uint8 cellIndex) internal {
        if (cellIndex < 64) {
            _revealedBits[0] |= (uint256(1) << cellIndex);
        } else {
            _revealedBits[1] |= (uint256(1) << (cellIndex - 64));
        }
    }

    /// @dev Checks a bit in a memory-based bitset (used for claimCompletion validation).
    function _memBitGet(uint256[2] memory bitset, uint8 cellIndex) internal pure returns (bool) {
        if (cellIndex < 64) {
            return (bitset[0] & (uint256(1) << cellIndex)) != 0;
        }
        return (bitset[1] & (uint256(1) << (cellIndex - 64))) != 0;
    }

    /// @dev Sets a bit in a memory-based bitset (used for claimCompletion validation).
    function _memBitSet(uint256[2] memory bitset, uint8 cellIndex) internal pure {
        if (cellIndex < 64) {
            bitset[0] |= (uint256(1) << cellIndex);
        } else {
            bitset[1] |= (uint256(1) << (cellIndex - 64));
        }
    }
}
